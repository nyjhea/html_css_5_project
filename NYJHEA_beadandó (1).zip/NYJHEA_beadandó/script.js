document.getElementById('ellenorzesButton').addEventListener('click', function() {
    var helyesValaszok = {
        'valasz1': 'valasz1_1', // Kérdés 1 helyes válasza
        'valasz2': 'valasz2_2', // Kérdés 2 helyes válasza
        'valasz3': 'valasz3_1', // Kérdés 3 helyes válasza
        // Itt folytathatod a további kérdések helyes válaszaival
    };

    var helyesValaszokSzama = 0;
    var helytelenValaszokSzama = 0;
    var eredmeny;

    for (var kerdes in helyesValaszok) {
        var valasz = document.querySelector('input[name="' + kerdes + '"]:checked');
        var helyesValasz = helyesValaszok[kerdes];

        if (valasz && valasz.value === helyesValasz) {
            helyesValaszokSzama++;
        } else {
            helytelenValaszokSzama++;
        }
    }
    if (helyesValaszokSzama == 3) {
        eredmeny='Győztél! Nyertél egy Dyson porszívót!'
    } else {
        eredmeny='Vesztettél'
    }
    alert('Helyes válaszok száma: ' + helyesValaszokSzama + '\nHelytelen válaszok száma: ' + helytelenValaszokSzama
    + '\nEredmény: ' + eredmeny);
});