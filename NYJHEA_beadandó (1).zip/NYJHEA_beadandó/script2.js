document.getElementById('ellenorzesButton').addEventListener('click', function() {
    var helyesValaszok = {
        'valasz7': 'valasz7_3',
        'valasz8': 'valasz8_1',
        'valasz9': 'valasz9_3',
        // Itt folytathatod a további kérdések helyes válaszaival
    };

    var helyesValaszokSzama = 0;
    var helytelenValaszokSzama = 0;
    var eredmeny;

    for (var kerdes in helyesValaszok) {
        var valasz = document.querySelector('input[name="' + kerdes + '"]:checked');
        var helyesValasz = helyesValaszok[kerdes];

        if (valasz && valasz.value === helyesValasz) {
            helyesValaszokSzama++;
        } else {
            helytelenValaszokSzama++;
        }
    }
    if (helyesValaszokSzama == 3) {
        eredmeny='Győztél! Nyertél a Mecsektetőn egy kastélyt!'
    } else {
        eredmeny='Vesztettél'
    }
    alert('Helyes válaszok száma: ' + helyesValaszokSzama + '\nHelytelen válaszok száma: ' + helytelenValaszokSzama
    + '\nEredmény: ' + eredmeny);
});